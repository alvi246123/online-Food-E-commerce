function check() {
    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let phone = document.getElementById("phone").value.trim();
    let password = document.getElementById("password").value;
    let cpassword = document.getElementById("cpassword").value;
    let dobInput = document.getElementById("date").value;
    let isMale = document.getElementById("male").checked;
    let isFemale = document.getElementById("female").checked;
    let nid = document.getElementById("nid").value;
    let Vehicle = document.getElementById("Vehicle").value.trim();
    let msgbox = document.getElementById("message");
 
    if (name === "") {
        msgbox.innerHTML = "name must be declared";
        msgbox.style.color = "red";
        return;
    } 
    else if (/[0-9]/.test(name)){
        msgbox.innerHTML="can not use a number";
        msgbox.style.color="red";
        return;


    }
    else if (email === "") {
        msgbox.innerHTML = "email must be declared";
        msgbox.style.color = "red";
        return;
    }
    else if (email.includes("@") == false || email.includes(".") == false) {
        msgbox.innerHTML = "please enter a valid email";
        msgbox.style.color = "red";
        return;
    }
    else if (phone.length !== 11 || isNaN(phone)) {
        msgbox.innerHTML = "phone must be 11 character";
        msgbox.style.color = "red";
        return;
    }
    else if (phone.startsWith("013") == false && phone.startsWith("014") == false && phone.startsWith("015") == false && phone.startsWith("016") == false && phone.startsWith("017") == false && phone.startsWith("018") == false && phone.startsWith("019") == false) {
        msgbox.innerHTML = "phone number must starts with 013 to 019";
        msgbox.style.color = "red";
        return;
    }
    else if (password.length < 6 || !/[0-9]/.test(password)) {
        msgbox.innerHTML = "password must contain at least 6 characters";
        msgbox.style.color = "red";
        return;
    }
    
    else if (cpassword===""){
        msgbox.innerHTML="please input confirm password";
        msgbox.style.color="red";
        return;
    }
    else if (password !== cpassword) { 
        msgbox.innerHTML = "password not matched";
        msgbox.style.color = "red";
        return;
    }
    else if (dobInput === "") {
        msgbox.innerHTML = "please select your date of birth";
        msgbox.style.color = "red";
        return;
    }
    else if (isMale === false && isFemale === false) {
        msgbox.innerHTML = "please choose gender";
        msgbox.style.color = "red";
        return;
    }
    else if (isNaN(nid)) {
        msgbox.innerHTML = "This is not a number";
        msgbox.style.color = "red";
        return;
    }
    else if (nid.length !== 13 && nid.length !== 17) {
        msgbox.innerHTML = "Nid must contain 13 or 17 number";
        msgbox.style.color = "red";
        return;
    }
    else if (Vehicle === "") {
        msgbox.innerHTML = "please select a vehicle type";
        msgbox.style.color = "red";
        return;
    }
    else {
        window.location.href = "success.html";
       
    }
}