function check() {
 
    let name = document.getElementById("name").value.trim();
    let adminid = document.getElementById("adminid").value.trim();
    let email = document.getElementById("email").value.trim();
    let number = document.getElementById("number").value.trim();
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;
    let file = document.getElementById("file");
 
    let msgbox = document.getElementById("message");
 
    if (name === "") {
        msgbox.innerHTML = "Name must be declared";
        msgbox.style.color = "red";
        return;
    }
    
   
 
    else if (adminid === "") {
        msgbox.innerHTML = "ID must be declared";
        msgbox.style.color = "red";
        return;
    }
 
    else if (adminid.startsWith("adm") == false) {
        msgbox.innerHTML = "ID must start with adm";
        msgbox.style.color = "red";
        return;
    }
 
    else if (email === "") {
        msgbox.innerHTML = "Email must be declared";
        msgbox.style.color = "red";
        return;
    }
 
    else if (number.length != 11 || isNaN(number)) {
        msgbox.innerHTML = "Number must be 11 digits";
        msgbox.style.color = "red";
        return;
    }
 
    else if (
         number.startsWith("013") == false &&
        number.startsWith("018") == false &&
        number.startsWith("014") == false &&
        number.startsWith("015") == false &&
        number.startsWith("016") == false &&
        number.startsWith("017") == false &&
        number.startsWith("019") == false
    ) {
        msgbox.innerHTML = "Invalid phone number";
        msgbox.style.color = "red";
        return;
    }
 
    else if (password === "") {
        msgbox.innerHTML = "Password must be declared";
        msgbox.style.color = "red";
        return;
    }
   
   
 
    else if (confirmPassword === "") {
        msgbox.innerHTML = "Confirm password";
        msgbox.style.color = "red";
        return;
    }
 
    else if (password != confirmPassword) {
        msgbox.innerHTML = "Password does not match";
        msgbox.style.color = "red";
        return;
    }
 
    else if (file.files.length > 0 &&
        file.files[0].type != "image/jpeg" &&
        file.files[0].type != "image/png") {
 
        msgbox.innerHTML = "Only JPG and PNG allowed";
        msgbox.style.color = "red";
        return;
    }
 
    else if (file.files.length > 0 &&
        file.files[0].size > 2 * 1024 * 1024) {
 
        msgbox.innerHTML = "Image must be below 2 MB";
        msgbox.style.color = "red";
        return;
    }
 
    else {
        window.location.href = "success.html";
    }
 
}