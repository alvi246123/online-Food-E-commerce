function check() {
    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim().toLowerCase();
    let password = document.getElementById("password").value;
    let confirm = document.getElementById("confirm").value;
    let phone = document.getElementById("phone").value.trim();
    let dobInput = document.getElementById("date").value;

    let isMale = document.getElementById("male").checked;
    let isFemale = document.getElementById("female").checked;

    let address = document.getElementById("address").value.trim();
    let city = document.getElementById("city").value.trim();
    let food = document.getElementById("food").value.trim();

    let isVeg = document.getElementById("veg").checked;
    let isNonVeg = document.getElementById("nonveg").checked;
    let terms = document.getElementById("terms").checked;

    let msgbox = document.getElementById("message");

    
    if (name === "") {
        msgbox.innerHTML = "name must be filled out";
        msgbox.style.color = "red";
        return;
    }
    else if (name.length < 3) {
        msgbox.innerHTML = "name must contain at least 3 characters";
        msgbox.style.color = "red";
        return;
    }
    
    else if (/^[A-Za-z ]+$/.test(name) === false) {
        msgbox.innerHTML = "name must contain only letters and spaces";
        msgbox.style.color = "red";
        return;
    }

    // 2. email
    else if (email === "") {
        msgbox.innerHTML = "email must be declared";
        msgbox.style.color = "red";
        return;
    }
    
    else if (email === "abc@gmail.com" || email === "123@gmail.com" || email === "asd@gmail.com") {
        msgbox.innerHTML = "duplicate email";
        msgbox.style.color = "red";
        return;
    }

    // 3. password
    else if (password === "") {
        msgbox.innerHTML = "password must be filled out";
        msgbox.style.color = "red";
        return;
    }
    else if (password.length < 8) {
        msgbox.innerHTML = "password must contain at least 8 characters";
        msgbox.style.color = "red";
        return;
    }
    else if (password==password.toLowerCase())
    {
        msgbox.innerHTML="password must contain atleast one uppoercase";
        msgbox.style.color="red";
        return;
    }
    else if (confirm === "") {
        msgbox.innerHTML = "please confirm your password";
        msgbox.style.color = "red";
        return;
    }
    else if (password !== confirm) {
        msgbox.innerHTML = "password and confirm password do not match";
        msgbox.style.color = "red";
        return;
    }

    // 4. phone
    else if (phone === "") {
        msgbox.innerHTML = "phone must be filled out";
        msgbox.style.color = "red";
        return;
    }
    else if (phone.length !== 11 || isNaN(phone)) {
        msgbox.innerHTML = "phone must be 11 digits";
        msgbox.style.color = "red";
        return;
    }
    else if (/^01[3-9]/.test(phone) === false) {
        msgbox.innerHTML = "phone number must start with 013 to 019";
        msgbox.style.color = "red";
        return;
    }

    // 5. date of birth
    else if (dobInput === "") {
        msgbox.innerHTML = "please select your date of birth";
        msgbox.style.color = "red";
        return;
    }
    else if (dobInput > "2026-10-31") {
        msgbox.innerHTML = "date of birth can not be in the future";
        msgbox.style.color = "red";
        return;
    }
    else if (dobInput > "2013-10-31") {
        msgbox.innerHTML = "you must be at least 13 years old";
        msgbox.style.color = "red";
        return;
    }

    // 6. gender
    else if (isMale === false && isFemale === false) {
        msgbox.innerHTML = "please choose gender";
        msgbox.style.color = "red";
        return;
    }

    // 7. address
    else if (address === "") {
        msgbox.innerHTML = "address must be filled out";
        msgbox.style.color = "red";
        return;
    }
    else if (address.length < 10) {
        msgbox.innerHTML = "address must contain at least 10 characters";
        msgbox.style.color = "red";
        return;
    }

    // 8. city
    else if (city === "") {
        msgbox.innerHTML = "city must be selected";
        msgbox.style.color = "red";
        return;
    }
    else if (/[0-9]/.test(city)) {
        msgbox.innerHTML = "city must not contain numbers";
        msgbox.style.color = "red";
        return;
    }

    // 9. favorite food
    else if (food === "") {
        msgbox.innerHTML = "please select your favorite food";
        msgbox.style.color = "red";
        return;
    }

    // 10. food preference
    else if (isVeg === false && isNonVeg === false) {
        msgbox.innerHTML = "please choose a food preference";
        msgbox.style.color = "red";
        return;
    }

    // 11. terms
    else if (terms === false) {
        msgbox.innerHTML = "you must agree to the terms and conditions";
        msgbox.style.color = "red";
        return;
    }

    else {
       window.location.href = "success.html";
    }
}
