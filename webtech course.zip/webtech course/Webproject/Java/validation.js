function checkName() {
    let val = document.getElementById("name").value.trim();
    let err = document.getElementById("nameError");
    let pattern = /^[A-Za-z\s]+$/;

    if (val === "") {
        err.innerHTML = "Please enter full name";
    } else if (!pattern.test(val)) {
        err.innerHTML = "Name cannot contain numbers or special characters";
    } else {
        err.innerHTML = "";
    }
}

function checkEmail() {
    let val = document.getElementById("email").value.trim();
    let err = document.getElementById("emailError");

    if (val === "" || val.indexOf("@") === -1) {
        err.innerHTML = "Email must contain an '@' symbol";
    } else {
        err.innerHTML = "";
    }
}

function checkPhone() {
    let val = document.getElementById("phone").value.trim();
    let err = document.getElementById("phoneError");

    if (val.length !== 11 || isNaN(val)) {
        err.innerHTML = "Phone number must be exactly 11 digits";
    } else {
        err.innerHTML = "";
    }
}

function checkPassword() {
    let val = document.getElementById("password").value;
    let err = document.getElementById("passwordError");

    if (val.length < 6) {
        err.innerHTML = "Password must be at least 6 characters";
    } else {
        err.innerHTML = "";
    }
}

function checkConfirmPassword() {
    let pass = document.getElementById("password").value;
    let cpass = document.getElementById("confirmPassword").value;
    let err = document.getElementById("confirmPasswordError");

    if (pass !== cpass) {
        err.innerHTML = "Passwords do not match";
    } else {
        err.innerHTML = "";
    }
}

// 6. Manager ID: Starts with MGR + 4 digits
function checkManagerId() {
    let val = document.getElementById("managerId").value.trim();
    let err = document.getElementById("managerIdError");
    let pattern = /^MGR\d{4}$/;

    if (!pattern.test(val)) {
        err.innerHTML = "Manager ID must start with 'MGR' and exactly 4 digits";
    } else {
        err.innerHTML = "";
    }
}

// 7. Restaurant/Branch Name: At least 3 characters
function checkRestaurantName() {
    let val = document.getElementById("restaurantName").value;
    let err = document.getElementById("restaurantNameError");

    if (val.trim().length < 3) {
        err.innerHTML = "Restaurant or branch name must contain at least 3 characters";
    } else {
        err.innerHTML = "";
    }
}

// 8. Restaurant Address: At least 10 characters
function checkRestaurantAddress() {
    let val = document.getElementById("restaurantAddress").value;
    let err = document.getElementById("restaurantAddressError");

    if (val.trim().length < 10) {
        err.innerHTML = "Restaurant address must contain at least 10 characters";
    } else {
        err.innerHTML = "";
    }
}

function checkNid() {
    let val = document.getElementById("nid").value.trim();
    let err = document.getElementById("nidError");

    if (val !== "" && val.length < 5) {
        err.innerHTML = "Invalid NID or Employee ID format";
    } else {
        err.innerHTML = "";
    }
}

function checkProfilePic() {
    let fileInput = document.getElementById("profilePic");
    let err = document.getElementById("profilePicError");

    if (fileInput && fileInput.files.length > 0) {
        let file = fileInput.files[0];
        let fileSize = file.size / 1024 / 1024;
        let extension = file.name.split('.').pop().toLowerCase();

        if (extension !== "jpg" && extension !== "png") {
            err.innerHTML = "Only JPG or PNG files are allowed";
        } else if (fileSize > 2) {
            err.innerHTML = "Maximum file size is 2 MB";
        } else {
            err.innerHTML = "";
        }
    } else {
        if (err) err.innerHTML = "";
    }
}


function check() {
    checkName();
    checkEmail();
    checkPhone();
    checkPassword();
    checkConfirmPassword();
    checkManagerId();
    checkRestaurantName();
    checkRestaurantAddress();
    checkNid();
    checkProfilePic();

    let errs = [
        document.getElementById("nameError").innerHTML,
        document.getElementById("emailError").innerHTML,
        document.getElementById("phoneError").innerHTML,
        document.getElementById("passwordError").innerHTML,
        document.getElementById("confirmPasswordError").innerHTML,
        document.getElementById("managerIdError").innerHTML,
        document.getElementById("restaurantNameError").innerHTML,
        document.getElementById("restaurantAddressError").innerHTML,
        document.getElementById("nidError").innerHTML,
        document.getElementById("profilePicError").innerHTML
    ];

    for (let i = 0; i < errs.length; i++) {
        if (errs[i] !== "") {
            return false;
        }
    }
    return true;
}


function submitForm() {
    let isValid = check();

    if (isValid === true) {
        
        window.location.href = "success.html";
    }
}